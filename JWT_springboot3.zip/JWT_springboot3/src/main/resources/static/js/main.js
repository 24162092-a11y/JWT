$(function () {
    $("#login-form").on("submit", function (event) {
        event.preventDefault();

        const credentials = {
            email: $("#email").val(),
            password: $("#password").val()
        };

        $.ajax({
            type: "POST",
            url: "/auth/login",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(credentials),
            success: function (data) {
                localStorage.setItem("token", data.token);
                window.location.href = "/user/profile";
            },
            error: function () {
                $("#feedback").text("Đăng nhập thất bại. Vui lòng kiểm tra email và mật khẩu.");
            }
        });
    });

    if ($("#profile").length) {
        $.ajax({
            type: "GET",
            url: "/users/me",
            dataType: "json",
            beforeSend: function (xhr) {
                const token = localStorage.getItem("token");
                if (token) {
                    xhr.setRequestHeader("Authorization", "Bearer " + token);
                }
            },
            success: function (user) {
                $("#profile").text(user.fullName || user.username);
                if (user.images) {
                    $("#images").attr("src", user.images).prop("hidden", false);
                }
            },
            error: function () {
                localStorage.removeItem("token");
                window.location.href = "/login";
            }
        });
    }

    $("#logout").on("click", function () {
        localStorage.removeItem("token");
        window.location.href = "/login";
    });
});
