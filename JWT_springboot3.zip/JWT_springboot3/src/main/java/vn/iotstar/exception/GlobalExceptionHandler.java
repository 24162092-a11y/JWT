package vn.iotstar.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.security.authentication.AccountStatusException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import vn.iotstar.services.JwtService.ExpiredJwtTokenException;
import vn.iotstar.services.JwtService.InvalidJwtTokenException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public ProblemDetail handleException(Exception exception) {
        if (exception instanceof BadCredentialsException) {
            return problem(HttpStatus.UNAUTHORIZED, exception.getMessage(),
                    "The username or password is incorrect");
        }
        if (exception instanceof AccountStatusException) {
            return problem(HttpStatus.FORBIDDEN, exception.getMessage(),
                    "The account is locked");
        }
        if (exception instanceof AccessDeniedException) {
            return problem(HttpStatus.FORBIDDEN, exception.getMessage(),
                    "You are not authorized to access this resource");
        }
        if (exception instanceof ExpiredJwtTokenException) {
            return problem(HttpStatus.UNAUTHORIZED, exception.getMessage(),
                    "The JWT token has expired");
        }
        if (exception instanceof InvalidJwtTokenException) {
            return problem(HttpStatus.UNAUTHORIZED, exception.getMessage(),
                    "The JWT signature is invalid");
        }
        if (exception instanceof HttpRequestMethodNotSupportedException) {
            return problem(HttpStatus.METHOD_NOT_ALLOWED, exception.getMessage(),
                    "Use the HTTP method supported by this endpoint.");
        }

        logger.error("Unhandled request exception", exception);
        return problem(HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected error occurred",
                "Unknown internal server error.");
    }

    private ProblemDetail problem(HttpStatus status, String detail, String description) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(status, detail);
        problem.setProperty("description", description);
        return problem;
    }
}
