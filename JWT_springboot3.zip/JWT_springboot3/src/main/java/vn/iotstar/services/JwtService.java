package vn.iotstar.services;

import java.security.SecureRandom;
import java.text.ParseException;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import jakarta.annotation.PostConstruct;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class JwtService {

    private static final Logger logger = LoggerFactory.getLogger(JwtService.class);
    private static final JWSAlgorithm SIGNING_ALGORITHM = JWSAlgorithm.HS256;

    @Value("${security.jwt.secret-key:}")
    private String secretKey;

    @Value("${security.jwt.expiration-time}")
    private long jwtExpiration;

    @PostConstruct
    private void initializeSecretKey() {
        if (secretKey == null || secretKey.isBlank()) {
            byte[] keyBytes = new byte[32];
            new SecureRandom().nextBytes(keyBytes);
            secretKey = Base64.getEncoder().encodeToString(keyBytes);
            logger.warn("JWT_SECRET is not configured. A temporary signing key was generated; tokens will be invalid after restart.");
            return;
        }

        getSignInKey();
    }

    public String extractUsername(String token) {
        return extractClaim(token, JWTClaimsSet::getSubject);
    }

    public <T> T extractClaim(String token, Function<JWTClaimsSet, T> claimsResolver) {
        return claimsResolver.apply(extractAllClaims(token));
    }

    public String generateToken(UserDetails userDetails) {
        return generateToken(new HashMap<>(), userDetails);
    }

    public String generateToken(Map<String, Object> extraClaims, UserDetails userDetails) {
        Date issuedAt = new Date();
        JWTClaimsSet.Builder claimsBuilder = new JWTClaimsSet.Builder();
        extraClaims.forEach(claimsBuilder::claim);
        JWTClaimsSet claims = claimsBuilder
                .subject(userDetails.getUsername())
                .issueTime(issuedAt)
                .expirationTime(new Date(issuedAt.getTime() + jwtExpiration))
                .build();

        SignedJWT signedJWT = new SignedJWT(new JWSHeader(SIGNING_ALGORITHM), claims);
        try {
            signedJWT.sign(new MACSigner(getSignInKey().getEncoded()));
            return signedJWT.serialize();
        } catch (JOSEException exception) {
            throw new IllegalStateException("Unable to sign JWT", exception);
        }
    }

    public long getExpirationTime() {
        return jwtExpiration;
    }

    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return username.equals(userDetails.getUsername());
    }

    private JWTClaimsSet extractAllClaims(String token) {
        try {
            SignedJWT signedJWT = SignedJWT.parse(token);
            if (!SIGNING_ALGORITHM.equals(signedJWT.getHeader().getAlgorithm())
                    || !signedJWT.verify(new MACVerifier(getSignInKey().getEncoded()))) {
                throw new InvalidJwtTokenException("JWT signature is invalid");
            }

            JWTClaimsSet claims = signedJWT.getJWTClaimsSet();
            Date expiration = claims.getExpirationTime();
            if (expiration == null || !expiration.after(new Date())) {
                throw new ExpiredJwtTokenException("JWT token has expired or has no expiration");
            }
            return claims;
        } catch (InvalidJwtTokenException exception) {
            throw exception;
        } catch (ParseException | JOSEException | IllegalArgumentException exception) {
            throw new InvalidJwtTokenException("JWT token is invalid", exception);
        }
    }

    private SecretKey getSignInKey() {
        byte[] keyBytes;
        try {
            keyBytes = Base64.getDecoder().decode(secretKey);
        } catch (IllegalArgumentException exception) {
            throw new IllegalStateException("JWT_SECRET must be a Base64-encoded key", exception);
        }

        if (keyBytes.length < 32) {
            throw new IllegalStateException("JWT_SECRET must contain at least 256 bits");
        }
        return new SecretKeySpec(keyBytes, "HmacSHA256");
    }

    public static class InvalidJwtTokenException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public InvalidJwtTokenException(String message) {
            super(message);
        }

        public InvalidJwtTokenException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public static final class ExpiredJwtTokenException extends InvalidJwtTokenException {
        private static final long serialVersionUID = 1L;

        public ExpiredJwtTokenException(String message) {
            super(message);
        }
    }
}
